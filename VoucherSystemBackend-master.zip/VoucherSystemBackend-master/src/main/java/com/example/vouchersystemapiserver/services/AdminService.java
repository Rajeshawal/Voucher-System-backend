package com.example.vouchersystemapiserver.services;

import org.springframework.stereotype.Service;

@Service
public class AdminService {

}
