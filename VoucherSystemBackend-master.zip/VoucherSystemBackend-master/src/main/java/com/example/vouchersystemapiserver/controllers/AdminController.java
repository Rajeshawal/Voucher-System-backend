package com.example.vouchersystemapiserver.controllers;

public class AdminController {
}
